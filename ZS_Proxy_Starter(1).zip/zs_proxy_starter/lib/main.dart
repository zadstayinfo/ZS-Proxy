import 'package:flutter/material.dart';

void main() => runApp(const ZSProxyApp());

const bg = Color(0xFF090B12);
const panel = Color(0xFF141927);
const accent = Color(0xFF8B5CF6);

class ZSProxyApp extends StatelessWidget {
  const ZSProxyApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ZS Proxy',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          scaffoldBackgroundColor: bg,
          colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark),
          cardColor: panel,
        ),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selected = 0;
  final pages = const ['Dashboard', 'Modules', 'Script Library', 'License', 'Settings'];
  final icons = const [Icons.dashboard_rounded, Icons.extension_rounded, Icons.code_rounded, Icons.key_rounded, Icons.settings_rounded];

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 760;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: bg,
        titleSpacing: 20,
        title: const Row(children: [
          Icon(Icons.bolt_rounded, color: accent, size: 27),
          SizedBox(width: 9),
          Text('ZS PROXY', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4)),
        ]),
        actions: const [Padding(padding: EdgeInsets.only(right: 18), child: Center(child: _StatusPill()))],
      ),
      body: Row(children: [
        if (wide) NavigationRail(
          backgroundColor: const Color(0xFF0D111B),
          selectedIndex: selected,
          onDestinationSelected: (v) => setState(() => selected = v),
          labelType: NavigationRailLabelType.all,
          destinations: [for (var i = 0; i < pages.length; i++) NavigationRailDestination(icon: Icon(icons[i]), label: Text(pages[i]))],
        ),
        Expanded(child: _content()),
      ]),
      bottomNavigationBar: wide ? null : NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (v) => setState(() => selected = v),
        destinations: [for (var i = 0; i < pages.length; i++) NavigationDestination(icon: Icon(icons[i]), label: pages[i])],
      ),
    );
  }

  Widget _content() {
    if (selected == 1) return _modules();
    if (selected == 2) return _scripts();
    if (selected == 3) return _license();
    if (selected == 4) return _settings();
    return _dashboard();
  }

  Widget _dashboard() => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('WELCOME BACK', style: TextStyle(color: accent, letterSpacing: 2, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('Your control center.', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
    const SizedBox(height: 18),
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFF30205C), Color(0xFF171C32)])), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('ZS PROXY • INDEPENDENT EDITION', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1.2)),
      SizedBox(height: 10), Text('Build your own\nautomation workspace.', style: TextStyle(fontSize: 25, height: 1.15, fontWeight: FontWeight.w900)),
      SizedBox(height: 12), Text('Android + Windows • Modular architecture', style: TextStyle(color: Colors.white70)),
    ])),
    const SizedBox(height: 16),
    const Wrap(spacing: 12, runSpacing: 12, children: [
      _StatCard(icon: Icons.extension, title: 'Modules', value: '0 active', note: 'Ready to configure'),
      _StatCard(icon: Icons.folder_copy, title: 'Scripts', value: '0 files', note: 'Library is empty'),
      _StatCard(icon: Icons.verified_user, title: 'License', value: 'FREE', note: 'Starter mode'),
    ]),
    const SizedBox(height: 22),
    const Text('GETTING STARTED', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)),
    const SizedBox(height: 10),
    const _StepTile(number: '01', title: 'Set up your project', detail: 'Connect the source code to your GitHub repository.'),
    const _StepTile(number: '02', title: 'Add the Lua runtime', detail: 'Choose and integrate a standalone Lua engine.'),
    const _StepTile(number: '03', title: 'Connect game features', detail: 'Implement supported integrations and test each module.'),
  ]);

  Widget _modules() => _page('Module Manager', 'Independent modules will be added here.', const [
    ('Auto Farm', 'Automation module placeholder', Icons.agriculture),
    ('World Tools', 'World utility module placeholder', Icons.public),
    ('Inventory', 'Inventory helper placeholder', Icons.inventory_2),
  ]);
  Widget _scripts() => _page('Script Library', 'Import, organize and manage your Lua scripts.', const [
    ('Local scripts', 'No scripts imported yet', Icons.code),
  ]);
  Widget _license() => _page('License Center', 'License activation will be connected to your own backend.', const [
    ('Current plan', 'FREE • Starter access', Icons.key),
    ('PRO key', 'Activation is not connected yet', Icons.lock),
  ]);
  Widget _settings() => _page('Settings', 'Application preferences.', const [
    ('Appearance', 'Dark theme', Icons.dark_mode),
    ('Updates', 'Update service not connected', Icons.system_update),
  ]);

  Widget _page(String title, String subtitle, List<(String, String, IconData)> items) => ListView(padding: const EdgeInsets.all(20), children: [
    Text(title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
    const SizedBox(height: 6), Text(subtitle, style: const TextStyle(color: Colors.white60)),
    const SizedBox(height: 18),
    for (final item in items) Card(color: panel, child: ListTile(leading: Icon(item.$3, color: accent), title: Text(item.$1), subtitle: Text(item.$2), trailing: const Icon(Icons.chevron_right))),
  ]);
}

class _StatusPill extends StatelessWidget {
  const _StatusPill();
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6), decoration: BoxDecoration(color: const Color(0xFF123A2B), borderRadius: BorderRadius.circular(30)), child: const Text('STARTER', style: TextStyle(color: Color(0xFF6EE7B7), fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)));
}

class _StatCard extends StatelessWidget {
  final IconData icon; final String title; final String value; final String note;
  const _StatCard({required this.icon, required this.title, required this.value, required this.note});
  @override
  Widget build(BuildContext context) => SizedBox(width: 210, child: Card(color: panel, child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: accent), const SizedBox(height: 12), Text(title, style: const TextStyle(color: Colors.white60)), const SizedBox(height: 4), Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text(note, style: const TextStyle(color: Colors.white38, fontSize: 11))]))));
}

class _StepTile extends StatelessWidget {
  final String number; final String title; final String detail;
  const _StepTile({required this.number, required this.title, required this.detail});
  @override
  Widget build(BuildContext context) => Card(color: panel, child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFF30205C), child: Text(number, style: const TextStyle(color: Colors.white))), title: Text(title), subtitle: Text(detail)));
}
