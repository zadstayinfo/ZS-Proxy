# ZS Proxy — starter project

This is the first UI scaffold for an independent Android + Windows app.

## Build

The GitHub Actions workflow in `.github/workflows/build.yml` builds:
- Android release APK
- Windows release application folder

Push the project to a GitHub repository on the `main` branch, then open **Actions → Build ZS Proxy** and download the artifacts after a successful run.

## Important architecture note

The current app is a UI starter only. It does not execute Growtopia automation or PowerKuy-specific scripts yet. A standalone Lua runtime and a separately implemented, permitted integration layer are required. Lua scripts that call PowerKuy-only APIs will not become compatible just by importing them; those APIs need compatible replacements and testing.

## Next milestones

1. Finish responsive UI and navigation.
2. Integrate a standalone Lua runtime.
3. Define a safe plugin/module API.
4. Add local script import and permissions.
5. Add a backend for account and license validation.
6. Implement and test individual integrations.
